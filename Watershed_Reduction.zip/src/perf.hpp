#ifndef PERF_HPP_INCLUDED
#define PERF_HPP_INCLUDED

/***
*** a timer to get performance information
***/

double getMillisecondsNow();
#endif // PERF_HPP_INCLUDED
